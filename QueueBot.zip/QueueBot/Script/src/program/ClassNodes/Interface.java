package program.ClassNodes;
import program.main;

public interface Interface {

}
