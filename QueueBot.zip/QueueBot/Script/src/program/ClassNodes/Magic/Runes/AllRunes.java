package program.ClassNodes.Magic.Runes;

public class AllRunes {
}
