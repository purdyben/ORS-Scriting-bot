package program.ClassNodes.Magic;

public class magicSpells {
}
