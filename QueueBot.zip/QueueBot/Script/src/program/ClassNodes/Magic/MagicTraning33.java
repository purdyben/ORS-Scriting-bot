package program.ClassNodes.Magic;

public class MagicTraning33 {
}
