package program.ClassNodes.Magic;

public class MagicGear {
}
