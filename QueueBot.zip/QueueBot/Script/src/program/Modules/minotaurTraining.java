package program.Modules;

public class minotaurTraining {
}
